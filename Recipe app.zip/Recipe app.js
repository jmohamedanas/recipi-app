import './index.css';
import React from "react";
import { Provider } from "react-redux";
import store from "./redux/store";
import RecipeList from "./components/RecipeList";
import SearchBar from "./components/SearchBar";
import Filters from "./components/Filters";
import Favorites from "./components/Favorites";

function App() {
  return (
    <Provider store={store}>
      <div className="container mx-auto p-4">
        <h1 className="text-3xl font-bold text-center mb-4">Recipe App</h1>
        <SearchBar />
        <Filters />
        <RecipeList />
        <Favorites />
      </div>
    </Provider>
  );
}

export default App;

// Redux setup (src/redux/store.js)
import { configureStore } from "@reduxjs/toolkit";
import recipesReducer from "./slices/recipesSlice";
import favoritesReducer from "./slices/favoritesSlice";

const store = configureStore({
  reducer: {
    recipes: recipesReducer,
    favorites: favoritesReducer,
  },
});